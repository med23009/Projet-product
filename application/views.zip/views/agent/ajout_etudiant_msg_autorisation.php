<?php include(APPPATH.'views/include/header.php');
    include('include/menu.php');?>
   
  <div class="container">
    <div class="col-xs-12 hl-left">           
         
   
      <?php echo $this->session->flashdata('msg'); ?>
   
     </div><!-- end of right content-->                 
  </div>   <!--end of center content -->   
  
<div class="clear"></div>
</div> <!--end of main content-->
	
<?php include(APPPATH.'views/include/footer.php');?>