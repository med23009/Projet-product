<?php include(APPPATH.'views/include/header.php');
    include('include/menu.php');?>
<div class="container">
    <div class="col-xs-12 hl-left">

         <?php echo heading($titre,'3');
           $attributes = array('class' => 'niceform');
          
            if(isset($inscrire)||isset($desinscrire))
            {
                echo form_open('scolarite/afficher_cours');
                echo '<div style="height:40px;"></div>';
                echo '<table class="form" id="tableBizarre">';
            }
            else
            {
                echo form_open('scolarite/afficher_cours',$attributes);
                echo '<table class="form" id="tableProf">';
            }
          ?>
        
            <tr>
                <th style="text-align:left;">Année</th>
                <th style="text-align:left;">Semestre</th>
                <?php
                if(isset($inscrire))
                {
                    if($inscrire == 'inscrire')
                    {echo '<th style="text-align:left;">Étudiants du programme</th>';}
                }

                ?>
            </tr>
            <tr>
                <td>
                <?php
                echo ' <select name="annee" id=""> ';
                 echo '<option value="'.$courante['annee'][0].'">'.$courante['annee'][0].'</option>';
                for($i=0;$i<count($annee['date']);$i++)
                {
                    if($courante['annee'][0] != $annee['date'][$i])
                        echo '<option value="'.$annee['date'][$i].'">'.$annee['date'][$i].'</option>';
                }
                    

                echo '</select>';
               
                if(isset($inscrire))
                {
                    echo form_hidden('inscrire',$inscrire);
                }
                   /*
     * fonction pour convertir le code du semestre par son nom 
     * elle prend en parametre le numero du semestre soit(1,2,3)
     * et elle retourne le nom (Automn,ete,printemps)
     */
    function get_session_nom($numeroSemestre)
    {
        if($numeroSemestre == 3)
        {
            return 'Automne';
        }
        elseif($numeroSemestre == 2)
        {
            return 'Été';
        }
        else
        {
            return 'Printemps';
        }
    }
                ?>
                </td>
                <td>
                    <select  name="session" id="">
                        <?php 
                         echo '<option value="'.$courante['semestre'][0].'">'.get_session_nom($courante['semestre'][0]).'</option>';
                         if($courante['semestre'][0] == '1')
                         {
                             echo '<option value="03">Automne</option>
                              <option value="02">Été</option>';
                         }
                         elseif($courante['semestre'][0] == '2')
                         {
                            echo '<option value="03">Automne</option>
                            <option value="01">Printemps</option>';
                         }
                        else 
                        {
                            echo '<option value="01">Printemps</option>
                            <option value="02">Été</option>';
                        }
                             
                        ?>
                    </select>
                </td>
                 <td>
                    <?php
                    if(isset($inscrire))
                    {
                        if($inscrire == 'inscrire')
                        {
                        echo ' <select name="programme" id=""> ';
                        for($i=0;$i<count($programme['idProgramme']);$i++)
                        echo '<option value="'.$programme['idProgramme'][$i].'">'.$programme['nomProgramme'][$i].'</option>';

                        echo '</select>';
                        }
                    }
                ?>
                </td>
            </tr>
            <tr style="height: 20px;"></tr>
            <tr>
                 <td class="submit">
                 <?php $pw = array('type' => 'submit', 'name' => 'submit', 'id'=>'submit', 'value'=>'Suivant');
                 echo form_input($pw);?>
                 </td>
            </tr>
         </table>
        <?php echo form_close('</div>');?>
           </div>
           <div class="clear"></div>
    </div> <!--end of main content-->

    <?php
  include(APPPATH.'views/include/footer.php');?>


